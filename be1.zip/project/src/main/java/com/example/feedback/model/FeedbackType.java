package com.example.feedback.model;

public enum FeedbackType {
    SUGGESTION,
    BUG,
    QUESTION,
    PRAISE,
    OTHER
}