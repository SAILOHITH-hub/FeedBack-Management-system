package com.example.feedback.service;

import com.example.feedback.model.Feedback;
import com.example.feedback.repository.FeedbackRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FeedbackService {
    private final FeedbackRepository feedbackRepository;

    @Transactional(readOnly = true)
    public List<Feedback> getAllFeedback() {
        return feedbackRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Feedback getFeedbackById(String id) {
        return feedbackRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Feedback not found"));
    }

    @Transactional
    public Feedback createFeedback(Feedback feedback) {
        return feedbackRepository.save(feedback);
    }

    @Transactional
    public Feedback updateFeedback(String id, Feedback feedback) {
        Feedback existing = getFeedbackById(id);
        // Update fields
        existing.setStatus(feedback.getStatus());
        existing.setResponse(feedback.getResponse());
        existing.setResolved(feedback.isResolved());
        existing.setAssignedTo(feedback.getAssignedTo());
        return feedbackRepository.save(existing);
    }

    @Transactional
    public void deleteFeedback(String id) {
        feedbackRepository.deleteById(id);
    }
}