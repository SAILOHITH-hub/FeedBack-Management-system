package com.example.feedback.model;

public enum FeedbackStatus {
    NEW,
    IN_PROGRESS,
    RESOLVED,
    CLOSED
}