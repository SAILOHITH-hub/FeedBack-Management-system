import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Feedback, 
  FeedbackFilter, 
  FeedbackStats,
  User
} from '../types';
import { mockFeedbacks, mockUsers, calculateStats } from '../data/mockData';
import { filterFeedback } from '../utils/helpers';

interface FeedbackContextType {
  feedbacks: Feedback[];
  filteredFeedbacks: Feedback[];
  stats: FeedbackStats;
  users: User[];
  currentUser: User | null;
  filter: FeedbackFilter;
  setFilter: (filter: FeedbackFilter) => void;
  addFeedback: (feedback: Omit<Feedback, 'id' | 'createdAt' | 'updatedAt' | 'status' | 'isResolved' | 'assignedTo' | 'response'>) => void;
  updateFeedback: (id: string, updates: Partial<Feedback>) => void;
  deleteFeedback: (id: string) => void;
  getFeedbackById: (id: string) => Feedback | undefined;
  setCurrentUser: (user: User | null) => void;
}

const defaultFilter: FeedbackFilter = {
  search: '',
  type: '',
  category: '',
  status: '',
  dateRange: {
    from: null,
    to: null
  },
  minRating: null,
  maxRating: null,
  tags: [],
  assignedTo: null
};

const FeedbackContext = createContext<FeedbackContextType | undefined>(undefined);

export const FeedbackProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>(mockFeedbacks);
  const [users] = useState<User[]>(mockUsers);
  const [currentUser, setCurrentUser] = useState<User | null>(mockUsers[0]); // Default to first user
  const [filter, setFilter] = useState<FeedbackFilter>(defaultFilter);
  const [filteredFeedbacks, setFilteredFeedbacks] = useState<Feedback[]>(feedbacks);
  const [stats, setStats] = useState<FeedbackStats>(calculateStats(feedbacks));

  // Apply filters when feedbacks or filter changes
  useEffect(() => {
    const filtered = filterFeedback(feedbacks, filter);
    setFilteredFeedbacks(filtered);
  }, [feedbacks, filter]);

  // Recalculate stats when feedbacks change
  useEffect(() => {
    setStats(calculateStats(feedbacks));
  }, [feedbacks]);

  const addFeedback = (newFeedback: Omit<Feedback, 'id' | 'createdAt' | 'updatedAt' | 'status' | 'isResolved' | 'assignedTo' | 'response'>) => {
    const feedbackWithDefaults: Feedback = {
      ...newFeedback,
      id: `feedback-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: null,
      status: 'new',
      isResolved: false,
      assignedTo: null,
      response: null
    } as Feedback;
    
    setFeedbacks(prev => [feedbackWithDefaults, ...prev]);
  };

  const updateFeedback = (id: string, updates: Partial<Feedback>) => {
    setFeedbacks(prev => 
      prev.map(feedback => 
        feedback.id === id 
          ? { ...feedback, ...updates, updatedAt: new Date() } 
          : feedback
      )
    );
  };

  const deleteFeedback = (id: string) => {
    setFeedbacks(prev => prev.filter(feedback => feedback.id !== id));
  };

  const getFeedbackById = (id: string) => {
    return feedbacks.find(feedback => feedback.id === id);
  };

  return (
    <FeedbackContext.Provider value={{
      feedbacks,
      filteredFeedbacks,
      stats,
      users,
      currentUser,
      filter,
      setFilter,
      addFeedback,
      updateFeedback,
      deleteFeedback,
      getFeedbackById,
      setCurrentUser
    }}>
      {children}
    </FeedbackContext.Provider>
  );
};

export const useFeedback = (): FeedbackContextType => {
  const context = useContext(FeedbackContext);
  if (context === undefined) {
    throw new Error('useFeedback must be used within a FeedbackProvider');
  }
  return context;
};