import { 
  Feedback, 
  FeedbackCategory, 
  FeedbackStatus, 
  FeedbackType,
  User,
  UserRole,
  FeedbackStats
} from '../types';

// Generate a random date within the last 30 days
const getRandomDate = (daysAgo = 30) => {
  const date = new Date();
  date.setDate(date.getDate() - Math.floor(Math.random() * daysAgo));
  return date;
};

// Generate mock users
export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Alex Johnson',
    email: 'alex@example.com',
    role: UserRole.ADMIN,
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100'
  },
  {
    id: '2',
    name: 'Sarah Miller',
    email: 'sarah@example.com',
    role: UserRole.MANAGER,
    avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=100'
  },
  {
    id: '3',
    name: 'David Wilson',
    email: 'david@example.com',
    role: UserRole.VIEWER,
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100'
  }
];

// Generate mock feedback data
export const mockFeedbacks: Feedback[] = Array.from({ length: 50 }, (_, index) => {
  const createdAt = getRandomDate();
  const isResolved = Math.random() > 0.6;
  const updatedAt = isResolved ? new Date(createdAt.getTime() + Math.random() * 86400000 * 5) : null;
  const type = Object.values(FeedbackType)[Math.floor(Math.random() * Object.values(FeedbackType).length)];
  
  const statuses = [FeedbackStatus.NEW, FeedbackStatus.IN_PROGRESS, FeedbackStatus.RESOLVED, FeedbackStatus.CLOSED];
  const status = isResolved 
    ? (Math.random() > 0.5 ? FeedbackStatus.RESOLVED : FeedbackStatus.CLOSED)
    : (Math.random() > 0.5 ? FeedbackStatus.NEW : FeedbackStatus.IN_PROGRESS);
  
  const allTags = ['urgent', 'feature request', 'ui/ux', 'performance', 'mobile', 'desktop', 'api', 'documentation'];
  const tags = Array.from({ length: Math.floor(Math.random() * 3) }, () => 
    allTags[Math.floor(Math.random() * allTags.length)]
  );
  
  return {
    id: `feedback-${index + 1}`,
    name: `Customer ${index + 1}`,
    email: `customer${index + 1}@example.com`,
    type,
    category: Object.values(FeedbackCategory)[Math.floor(Math.random() * Object.values(FeedbackCategory).length)],
    subject: [
      'Feature suggestion for dashboard',
      'Bug in checkout process',
      'Amazing customer service experience',
      'Question about pricing plan',
      'Website navigation issue',
      'Mobile app crashes frequently',
      'Great product quality',
      'Suggestion for improvement'
    ][Math.floor(Math.random() * 8)],
    message: [
      'I think it would be great if you could add a dark mode to the dashboard. It would make it easier to use at night.',
      'When I try to check out, the payment page keeps refreshing and I cannot complete my purchase.',
      'Your support team was incredibly helpful and resolved my issue quickly. Thank you!',
      'I\'m confused about the pricing structure. Is there a discount for annual plans?',
      'I find it difficult to navigate to the account settings page. The menu structure is confusing.',
      'Your mobile app crashes every time I try to upload a photo. This has been happening for weeks.',
      'I\'ve been using your product for 3 months now and it has significantly improved my workflow.',
      'I suggest adding keyboard shortcuts for common actions to improve productivity.'
    ][Math.floor(Math.random() * 8)],
    rating: Math.floor(Math.random() * 5) + 1,
    status,
    createdAt,
    updatedAt,
    tags: [...new Set(tags)], // Remove duplicates
    isResolved,
    assignedTo: isResolved ? (Math.random() > 0.3 ? '1' : '2') : (Math.random() > 0.7 ? '2' : null),
    response: isResolved && Math.random() > 0.3 
      ? 'Thank you for your feedback. We have addressed your concerns and made the necessary changes.' 
      : null
  };
});

// Calculate mock statistics
export const calculateStats = (feedbacks: Feedback[]): FeedbackStats => {
  const totalFeedbacks = feedbacks.length;
  
  // Count by status
  const statusCounts = {
    new: feedbacks.filter(f => f.status === FeedbackStatus.NEW).length,
    inProgress: feedbacks.filter(f => f.status === FeedbackStatus.IN_PROGRESS).length,
    resolved: feedbacks.filter(f => f.status === FeedbackStatus.RESOLVED).length,
    closed: feedbacks.filter(f => f.status === FeedbackStatus.CLOSED).length
  };
  
  // Calculate average rating
  const avgRating = feedbacks.reduce((acc, curr) => acc + curr.rating, 0) / totalFeedbacks;
  
  // Count by category
  const categoryDistribution = Object.values(FeedbackCategory).reduce((acc, category) => {
    acc[category] = feedbacks.filter(f => f.category === category).length;
    return acc;
  }, {} as Record<FeedbackCategory, number>);
  
  // Count by type
  const typeDistribution = Object.values(FeedbackType).reduce((acc, type) => {
    acc[type] = feedbacks.filter(f => f.type === type).length;
    return acc;
  }, {} as Record<FeedbackType, number>);
  
  return {
    total: totalFeedbacks,
    new: statusCounts.new,
    inProgress: statusCounts.inProgress,
    resolved: statusCounts.resolved,
    closed: statusCounts.closed,
    avgRating,
    categoryDistribution,
    typeDistribution
  };
};

export const mockStats = calculateStats(mockFeedbacks);