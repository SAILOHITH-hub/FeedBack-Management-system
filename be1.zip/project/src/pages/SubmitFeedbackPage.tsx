import React from 'react';
import Layout from '../components/layout/Layout';
import FeedbackForm from '../components/feedback/FeedbackForm';

const SubmitFeedbackPage: React.FC = () => {
  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            We Value Your Feedback
          </h1>
          <p className="mt-2 text-lg text-gray-600">
            Your feedback helps us improve our products and services.
          </p>
        </div>
        
        <FeedbackForm />
      </div>
    </Layout>
  );
};

export default SubmitFeedbackPage;