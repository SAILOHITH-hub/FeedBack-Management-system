import React from 'react';
import Layout from '../components/layout/Layout';
import FeedbackStats from '../components/dashboard/FeedbackStats';
import RecentFeedback from '../components/dashboard/RecentFeedback';
import CategoryDistribution from '../components/dashboard/CategoryDistribution';
import RatingDistribution from '../components/dashboard/RatingDistribution';
import { useFeedback } from '../context/FeedbackContext';

const Dashboard: React.FC = () => {
  const { currentUser } = useFeedback();
  
  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="md:flex md:items-center md:justify-between mb-6">
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
              Dashboard
            </h1>
            <p className="mt-1 text-sm text-gray-500">
              Welcome back, {currentUser?.name}! Here's an overview of your feedback data.
            </p>
          </div>
        </div>
        
        <div className="mb-8">
          <FeedbackStats />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <CategoryDistribution />
          <RatingDistribution />
        </div>
        
        <div className="mb-8">
          <RecentFeedback />
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;