import React from 'react';
import Layout from '../components/layout/Layout';
import FeedbackList from '../components/feedback/FeedbackList';
import FeedbackFilterComponent from '../components/feedback/FeedbackFilter';
import { useFeedback } from '../context/FeedbackContext';
import Button from '../components/ui/Button';
import { Download, PlusCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const FeedbackPage: React.FC = () => {
  const { filteredFeedbacks, filter, setFilter, users } = useFeedback();
  
  const exportFeedback = () => {
    // Create CSV content
    const headers = [
      'ID', 'Name', 'Email', 'Type', 'Category', 'Subject', 
      'Message', 'Rating', 'Status', 'Created At', 'Tags'
    ].join(',');
    
    const rows = filteredFeedbacks.map(feedback => [
      feedback.id,
      `"${feedback.name}"`,
      feedback.email,
      feedback.type,
      feedback.category,
      `"${feedback.subject.replace(/"/g, '""')}"`,
      `"${feedback.message.replace(/"/g, '""')}"`,
      feedback.rating,
      feedback.status,
      feedback.createdAt.toISOString(),
      `"${feedback.tags.join(', ')}"`
    ].join(','));
    
    const csvContent = [headers, ...rows].join('\n');
    
    // Create and download the file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('href', url);
    a.setAttribute('download', `feedback_export_${new Date().toISOString().slice(0, 10)}.csv`);
    a.click();
    URL.revokeObjectURL(url);
  };
  
  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="md:flex md:items-center md:justify-between mb-6">
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
              Feedback Management
            </h1>
            <p className="mt-1 text-sm text-gray-500">
              View, filter, and manage all feedback submissions.
            </p>
          </div>
          <div className="mt-4 flex md:mt-0 md:ml-4 space-x-3">
            <Button 
              variant="outline" 
              onClick={exportFeedback}
              icon={<Download className="h-4 w-4" />}
            >
              Export
            </Button>
            <Link to="/submit">
              <Button 
                variant="primary"
                icon={<PlusCircle className="h-4 w-4" />}
              >
                New Feedback
              </Button>
            </Link>
          </div>
        </div>
        
        <FeedbackFilterComponent 
          filter={filter}
          onFilterChange={setFilter}
          users={users}
        />
        
        <FeedbackList 
          feedbacks={filteredFeedbacks}
        />
      </div>
    </Layout>
  );
};

export default FeedbackPage;