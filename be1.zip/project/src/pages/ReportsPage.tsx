import React, { useState } from 'react';
import Layout from '../components/layout/Layout';
import Card, { CardHeader, CardBody } from '../components/ui/Card';
import { useFeedback } from '../context/FeedbackContext';
import Button from '../components/ui/Button';
import { BarChart, Download, PieChart, TrendingUp } from 'lucide-react';
import CategoryDistribution from '../components/dashboard/CategoryDistribution';
import RatingDistribution from '../components/dashboard/RatingDistribution';

const ReportsPage: React.FC = () => {
  const { stats, feedbacks } = useFeedback();
  const [activeTab, setActiveTab] = useState('overview');
  
  // Calculate time-based metrics for trend analysis
  const getMonthlyData = () => {
    const now = new Date();
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(now.getMonth() - 6);
    
    // Initialize data structure for monthly counts
    const monthlyData: { [key: string]: number } = {};
    for (let i = 0; i < 6; i++) {
      const date = new Date();
      date.setMonth(now.getMonth() - i);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      monthlyData[monthKey] = 0;
    }
    
    // Count feedbacks by month
    feedbacks.forEach(feedback => {
      const date = new Date(feedback.createdAt);
      if (date >= sixMonthsAgo) {
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        if (monthKey in monthlyData) {
          monthlyData[monthKey]++;
        }
      }
    });
    
    // Convert to array sorted by date
    return Object.entries(monthlyData)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, count]) => {
        const [year, monthNum] = month.split('-');
        const date = new Date(parseInt(year), parseInt(monthNum) - 1);
        return {
          month: date.toLocaleString('default', { month: 'short', year: 'numeric' }),
          count
        };
      });
  };
  
  const monthlyData = getMonthlyData();
  
  // Calculate average resolution time
  const getAverageResolutionTime = () => {
    const resolvedFeedbacks = feedbacks.filter(f => 
      f.isResolved && f.updatedAt
    );
    
    if (resolvedFeedbacks.length === 0) return 'N/A';
    
    const totalTimeMs = resolvedFeedbacks.reduce((total, feedback) => {
      const createdTime = feedback.createdAt.getTime();
      const resolvedTime = feedback.updatedAt!.getTime();
      return total + (resolvedTime - createdTime);
    }, 0);
    
    const avgTimeMs = totalTimeMs / resolvedFeedbacks.length;
    const avgDays = Math.floor(avgTimeMs / (1000 * 60 * 60 * 24));
    
    return avgDays === 0 
      ? 'Less than a day' 
      : `${avgDays} day${avgDays !== 1 ? 's' : ''}`;
  };
  
  const renderTrendChart = () => {
    const maxCount = Math.max(...monthlyData.map(d => d.count));
    const scale = maxCount > 0 ? 150 / maxCount : 1;
    
    return (
      <div className="mt-4">
        <div className="flex items-end justify-between h-[200px]">
          {monthlyData.map((data, index) => (
            <div key={index} className="flex flex-col items-center w-1/6">
              <div 
                className="w-12 bg-blue-500 rounded-t-md transition-all duration-500 ease-in-out hover:bg-blue-600"
                style={{ height: `${data.count * scale}px` }}
              ></div>
              <div className="text-xs mt-2 text-gray-600">{data.month}</div>
            </div>
          ))}
        </div>
      </div>
    );
  };
  
  const renderTabs = () => {
    return (
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          <button
            className={`
              border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300
              whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
              ${activeTab === 'overview' ? 'border-blue-500 text-blue-600' : ''}
            `}
            onClick={() => setActiveTab('overview')}
          >
            Overview
          </button>
          <button
            className={`
              border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300
              whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
              ${activeTab === 'trends' ? 'border-blue-500 text-blue-600' : ''}
            `}
            onClick={() => setActiveTab('trends')}
          >
            Trends
          </button>
          <button
            className={`
              border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300
              whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
              ${activeTab === 'distribution' ? 'border-blue-500 text-blue-600' : ''}
            `}
            onClick={() => setActiveTab('distribution')}
          >
            Distribution
          </button>
        </nav>
      </div>
    );
  };
  
  const renderOverviewTab = () => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardBody>
            <div className="flex items-center mb-3">
              <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                <BarChart className="h-5 w-5" />
              </div>
            </div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">Total Feedback</h3>
            <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
            <div className="mt-2 text-sm text-gray-600">
              From {feedbacks.length} unique submissions
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody>
            <div className="flex items-center mb-3">
              <div className="p-2 rounded-lg bg-green-50 text-green-600">
                <TrendingUp className="h-5 w-5" />
              </div>
            </div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">Feedback Resolution Rate</h3>
            <p className="text-2xl font-bold text-gray-900">
              {stats.total > 0 
                ? `${Math.round(((stats.resolved + stats.closed) / stats.total) * 100)}%` 
                : '0%'}
            </p>
            <div className="mt-2 text-sm text-gray-600">
              {stats.resolved + stats.closed} of {stats.total} resolved
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody>
            <div className="flex items-center mb-3">
              <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
                <PieChart className="h-5 w-5" />
              </div>
            </div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">Average Resolution Time</h3>
            <p className="text-2xl font-bold text-gray-900">{getAverageResolutionTime()}</p>
            <div className="mt-2 text-sm text-gray-600">
              Based on {feedbacks.filter(f => f.isResolved && f.updatedAt).length} resolved items
            </div>
          </CardBody>
        </Card>
      </div>
    );
  };
  
  const renderTrendsTab = () => {
    return (
      <Card>
        <CardHeader className="flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-900">Feedback Trends (Last 6 Months)</h2>
          <Button 
            variant="outline" 
            size="sm"
            icon={<Download className="h-4 w-4" />}
          >
            Export
          </Button>
        </CardHeader>
        <CardBody>
          {renderTrendChart()}
        </CardBody>
      </Card>
    );
  };
  
  const renderDistributionTab = () => {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <CategoryDistribution />
        <RatingDistribution />
      </div>
    );
  };
  
  const renderActiveTab = () => {
    switch (activeTab) {
      case 'overview':
        return renderOverviewTab();
      case 'trends':
        return renderTrendsTab();
      case 'distribution':
        return renderDistributionTab();
      default:
        return renderOverviewTab();
    }
  };
  
  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="md:flex md:items-center md:justify-between mb-6">
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
              Reports & Analytics
            </h1>
            <p className="mt-1 text-sm text-gray-500">
              Analyze feedback trends, distributions, and performance metrics.
            </p>
          </div>
          <div className="mt-4 flex md:mt-0 md:ml-4">
            <Button 
              variant="outline" 
              onClick={() => alert('Exporting reports...')}
              icon={<Download className="h-4 w-4" />}
            >
              Export Reports
            </Button>
          </div>
        </div>
        
        {renderTabs()}
        {renderActiveTab()}
      </div>
    </Layout>
  );
};

export default ReportsPage;