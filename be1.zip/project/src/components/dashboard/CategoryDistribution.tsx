import React from 'react';
import Card, { CardHeader, CardBody } from '../ui/Card';
import { useFeedback } from '../../context/FeedbackContext';
import { FeedbackCategory } from '../../types';
import { getCategoryLabel } from '../../utils/helpers';

const CategoryDistribution: React.FC = () => {
  const { stats } = useFeedback();
  
  // Calculate total for percentage
  const total = Object.values(stats.categoryDistribution).reduce((sum, count) => sum + count, 0);
  
  // Color mapping for different categories
  const categoryColors: Record<FeedbackCategory, string> = {
    [FeedbackCategory.PRODUCT]: 'bg-blue-500',
    [FeedbackCategory.SERVICE]: 'bg-green-500',
    [FeedbackCategory.WEBSITE]: 'bg-purple-500',
    [FeedbackCategory.PRICING]: 'bg-amber-500',
    [FeedbackCategory.SUPPORT]: 'bg-red-500',
    [FeedbackCategory.OTHER]: 'bg-gray-500',
  };
  
  return (
    <Card>
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-900">Feedback by Category</h2>
      </CardHeader>
      <CardBody>
        <div className="space-y-4">
          {Object.entries(stats.categoryDistribution).map(([category, count]) => {
            const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
            
            return (
              <div key={category} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-700">
                    {getCategoryLabel(category as FeedbackCategory)}
                  </span>
                  <span className="text-sm font-medium text-gray-900">{percentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div
                    className={`h-2.5 rounded-full ${categoryColors[category as FeedbackCategory]}`}
                    style={{ width: `${percentage}%` }}
                  ></div>
                </div>
              </div>
            );
          })}
        </div>
      </CardBody>
    </Card>
  );
};

export default CategoryDistribution;