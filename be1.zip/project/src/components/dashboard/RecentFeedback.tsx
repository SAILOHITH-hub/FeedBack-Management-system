import React from 'react';
import { Feedback } from '../../types';
import { useFeedback } from '../../context/FeedbackContext';
import Card, { CardHeader, CardBody } from '../ui/Card';
import { formatDate, getTypeIcon } from '../../utils/helpers';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import StarRating from '../ui/StarRating';

const RecentFeedback: React.FC = () => {
  const { feedbacks } = useFeedback();
  
  // Sort feedbacks by date (newest first) and take the first 5
  const recentFeedbacks = [...feedbacks]
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, 5);
  
  return (
    <Card>
      <CardHeader className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-900">Recent Feedback</h2>
        <Link 
          to="/feedback" 
          className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
        >
          View All
          <ChevronRight className="h-4 w-4 ml-1" />
        </Link>
      </CardHeader>
      <CardBody className="p-0">
        <div className="divide-y divide-gray-200">
          {recentFeedbacks.map((feedback) => (
            <FeedbackItem key={feedback.id} feedback={feedback} />
          ))}
        </div>
      </CardBody>
    </Card>
  );
};

interface FeedbackItemProps {
  feedback: Feedback;
}

const FeedbackItem: React.FC<FeedbackItemProps> = ({ feedback }) => {
  return (
    <Link to={`/feedback/${feedback.id}`} className="block hover:bg-gray-50 transition-colors duration-150">
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div className="flex items-start">
            <span className="mr-2 text-xl mt-1">{getTypeIcon(feedback.type)}</span>
            <div>
              <h3 className="text-sm font-medium text-gray-900">{feedback.subject}</h3>
              <p className="text-xs text-gray-500 mt-1">
                {feedback.name} • {formatDate(feedback.createdAt)}
              </p>
            </div>
          </div>
          <StarRating rating={feedback.rating} size="sm" />
        </div>
        <p className="mt-2 text-sm text-gray-600 line-clamp-2">
          {feedback.message}
        </p>
      </div>
    </Link>
  );
};

export default RecentFeedback;