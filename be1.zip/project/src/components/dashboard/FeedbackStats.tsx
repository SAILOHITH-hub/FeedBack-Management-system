import React from 'react';
import { useFeedback } from '../../context/FeedbackContext';
import StatCard from './StatCard';
import { BarChart2, CheckCircle, Clock, MessageSquare } from 'lucide-react';

const FeedbackStats: React.FC = () => {
  const { stats } = useFeedback();
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <StatCard
        title="Total Feedback"
        value={stats.total}
        icon={<MessageSquare className="h-5 w-5" />}
        color="blue"
      />
      <StatCard
        title="New Feedback"
        value={stats.new}
        icon={<BarChart2 className="h-5 w-5" />}
        color="amber"
        change={{ value: 12, type: 'increase' }}
      />
      <StatCard
        title="In Progress"
        value={stats.inProgress}
        icon={<Clock className="h-5 w-5" />}
        color="purple"
      />
      <StatCard
        title="Resolved"
        value={stats.resolved}
        icon={<CheckCircle className="h-5 w-5" />}
        color="green"
        change={{ value: 8, type: 'increase' }}
      />
    </div>
  );
};

export default FeedbackStats;