import React, { useState } from 'react';
import { FeedbackCategory, FeedbackFilter, FeedbackStatus, FeedbackType, User } from '../../types';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Button from '../ui/Button';
import { Search, X, Filter } from 'lucide-react';
import { getCategoryLabel, getStatusLabel, getTypeLabel } from '../../utils/helpers';

interface FeedbackFilterProps {
  filter: FeedbackFilter;
  onFilterChange: (filter: FeedbackFilter) => void;
  users: User[];
}

const FeedbackFilterComponent: React.FC<FeedbackFilterProps> = ({
  filter,
  onFilterChange,
  users
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [tempFilter, setTempFilter] = useState<FeedbackFilter>(filter);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setTempFilter(prev => ({ ...prev, [name]: value }));
  };
  
  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };
  
  const applyFilters = () => {
    onFilterChange(tempFilter);
    setIsExpanded(false);
  };
  
  const resetFilters = () => {
    const defaultFilter: FeedbackFilter = {
      search: '',
      type: '',
      category: '',
      status: '',
      dateRange: {
        from: null,
        to: null
      },
      minRating: null,
      maxRating: null,
      tags: [],
      assignedTo: null
    };
    
    setTempFilter(defaultFilter);
    onFilterChange(defaultFilter);
  };
  
  const statusOptions = [
    { value: '', label: 'All Statuses' },
    ...Object.values(FeedbackStatus).map(status => ({
      value: status,
      label: getStatusLabel(status)
    }))
  ];
  
  const typeOptions = [
    { value: '', label: 'All Types' },
    ...Object.values(FeedbackType).map(type => ({
      value: type,
      label: getTypeLabel(type)
    }))
  ];
  
  const categoryOptions = [
    { value: '', label: 'All Categories' },
    ...Object.values(FeedbackCategory).map(category => ({
      value: category,
      label: getCategoryLabel(category)
    }))
  ];
  
  const userOptions = [
    { value: '', label: 'Any Assignee' },
    ...users.map(user => ({
      value: user.id,
      label: user.name
    }))
  ];
  
  const isFilterActive = filter.search || filter.type || filter.category || filter.status || 
    filter.dateRange.from || filter.dateRange.to || filter.minRating || filter.maxRating || 
    filter.tags.length > 0 || filter.assignedTo;
  
  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden mb-6">
      <div className="p-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900">Filters</h3>
          <div className="flex space-x-2">
            {isFilterActive && (
              <Button
                variant="outline"
                size="sm"
                onClick={resetFilters}
                icon={<X className="h-4 w-4" />}
              >
                Clear
              </Button>
            )}
            <Button
              variant={isExpanded ? "primary" : "outline"}
              size="sm"
              onClick={toggleExpand}
              icon={<Filter className="h-4 w-4" />}
            >
              {isExpanded ? "Hide Filters" : "Show Filters"}
            </Button>
          </div>
        </div>
        
        <div className="mt-4">
          <Input
            id="search"
            name="search"
            placeholder="Search feedback..."
            value={tempFilter.search}
            onChange={handleInputChange}
            icon={<Search className="h-4 w-4 text-gray-400" />}
            className="mb-0"
          />
        </div>
        
        {isExpanded && (
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Select
              id="status"
              name="status"
              label="Status"
              options={statusOptions}
              value={tempFilter.status}
              onChange={handleInputChange}
            />
            
            <Select
              id="type"
              name="type"
              label="Type"
              options={typeOptions}
              value={tempFilter.type}
              onChange={handleInputChange}
            />
            
            <Select
              id="category"
              name="category"
              label="Category"
              options={categoryOptions}
              value={tempFilter.category}
              onChange={handleInputChange}
            />
            
            <Select
              id="assignedTo"
              name="assignedTo"
              label="Assigned To"
              options={userOptions}
              value={tempFilter.assignedTo || ''}
              onChange={handleInputChange}
            />
            
            <div className="col-span-1 md:col-span-2 lg:col-span-4 flex justify-end">
              <Button
                variant="primary"
                onClick={applyFilters}
              >
                Apply Filters
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default FeedbackFilterComponent;