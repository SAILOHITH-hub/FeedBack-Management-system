import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { FeedbackProvider } from './context/FeedbackContext';
import HomePage from './pages/HomePage';
import Dashboard from './pages/Dashboard';
import FeedbackPage from './pages/FeedbackPage';
import SubmitFeedbackPage from './pages/SubmitFeedbackPage';
import ReportsPage from './pages/ReportsPage';

function App() {
  return (
    <FeedbackProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/feedback" element={<FeedbackPage />} />
          <Route path="/submit" element={<SubmitFeedbackPage />} />
          <Route path="/reports" element={<ReportsPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </FeedbackProvider>
  );
}

export default App;