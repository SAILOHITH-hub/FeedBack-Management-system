package com.example.feedback.model;

public enum UserRole {
    ADMIN,
    MANAGER,
    VIEWER
}