package com.example.feedback.model;

public enum FeedbackCategory {
    PRODUCT,
    SERVICE,
    WEBSITE,
    PRICING,
    SUPPORT,
    OTHER
}