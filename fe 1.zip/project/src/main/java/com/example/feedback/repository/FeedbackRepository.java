package com.example.feedback.repository;

import com.example.feedback.model.Feedback;
import com.example.feedback.model.FeedbackStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

public interface FeedbackRepository extends JpaRepository<Feedback, String> {
    List<Feedback> findByStatus(FeedbackStatus status);
    List<Feedback> findByAssignedToId(String userId);
    List<Feedback> findByCreatedAtBetween(LocalDateTime start, LocalDateTime end);
    
    @Query("SELECT AVG(f.rating) FROM Feedback f")
    Double getAverageRating();
}