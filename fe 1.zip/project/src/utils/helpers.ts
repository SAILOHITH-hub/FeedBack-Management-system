import { 
  Feedback, 
  FeedbackCategory, 
  FeedbackFilter, 
  FeedbackStatus, 
  FeedbackType 
} from '../types';

export const formatDate = (date: Date): string => {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
};

export const getStatusColor = (status: FeedbackStatus): string => {
  switch (status) {
    case FeedbackStatus.NEW:
      return 'bg-blue-500';
    case FeedbackStatus.IN_PROGRESS:
      return 'bg-amber-500';
    case FeedbackStatus.RESOLVED:
      return 'bg-green-500';
    case FeedbackStatus.CLOSED:
      return 'bg-gray-500';
    default:
      return 'bg-gray-300';
  }
};

export const getTypeIcon = (type: FeedbackType): string => {
  switch (type) {
    case FeedbackType.SUGGESTION:
      return '💡';
    case FeedbackType.BUG:
      return '🐛';
    case FeedbackType.QUESTION:
      return '❓';
    case FeedbackType.PRAISE:
      return '🌟';
    case FeedbackType.OTHER:
      return '📝';
    default:
      return '📋';
  }
};

export const getStatusLabel = (status: FeedbackStatus): string => {
  switch (status) {
    case FeedbackStatus.NEW:
      return 'New';
    case FeedbackStatus.IN_PROGRESS:
      return 'In Progress';
    case FeedbackStatus.RESOLVED:
      return 'Resolved';
    case FeedbackStatus.CLOSED:
      return 'Closed';
    default:
      return 'Unknown';
  }
};

export const getCategoryLabel = (category: FeedbackCategory): string => {
  switch (category) {
    case FeedbackCategory.PRODUCT:
      return 'Product';
    case FeedbackCategory.SERVICE:
      return 'Service';
    case FeedbackCategory.WEBSITE:
      return 'Website';
    case FeedbackCategory.PRICING:
      return 'Pricing';
    case FeedbackCategory.SUPPORT:
      return 'Support';
    case FeedbackCategory.OTHER:
      return 'Other';
    default:
      return 'Unknown';
  }
};

export const getTypeLabel = (type: FeedbackType): string => {
  switch (type) {
    case FeedbackType.SUGGESTION:
      return 'Suggestion';
    case FeedbackType.BUG:
      return 'Bug';
    case FeedbackType.QUESTION:
      return 'Question';
    case FeedbackType.PRAISE:
      return 'Praise';
    case FeedbackType.OTHER:
      return 'Other';
    default:
      return 'Unknown';
  }
};

export const filterFeedback = (feedback: Feedback[], filter: FeedbackFilter): Feedback[] => {
  return feedback.filter(item => {
    // Search
    if (filter.search && 
      !(
        item.subject.toLowerCase().includes(filter.search.toLowerCase()) ||
        item.message.toLowerCase().includes(filter.search.toLowerCase()) ||
        item.name.toLowerCase().includes(filter.search.toLowerCase()) ||
        item.email.toLowerCase().includes(filter.search.toLowerCase())
      )
    ) {
      return false;
    }
    
    // Type
    if (filter.type && item.type !== filter.type) {
      return false;
    }
    
    // Category
    if (filter.category && item.category !== filter.category) {
      return false;
    }
    
    // Status
    if (filter.status && item.status !== filter.status) {
      return false;
    }
    
    // Date range - from
    if (filter.dateRange.from && item.createdAt < filter.dateRange.from) {
      return false;
    }
    
    // Date range - to
    if (filter.dateRange.to) {
      const toDateEnd = new Date(filter.dateRange.to);
      toDateEnd.setHours(23, 59, 59, 999);
      if (item.createdAt > toDateEnd) {
        return false;
      }
    }
    
    // Min rating
    if (filter.minRating !== null && item.rating < filter.minRating) {
      return false;
    }
    
    // Max rating
    if (filter.maxRating !== null && item.rating > filter.maxRating) {
      return false;
    }
    
    // Tags
    if (filter.tags.length > 0 && !filter.tags.some(tag => item.tags.includes(tag))) {
      return false;
    }
    
    // Assigned to
    if (filter.assignedTo !== null && item.assignedTo !== filter.assignedTo) {
      return false;
    }
    
    return true;
  });
};

export const sortFeedback = (feedback: Feedback[], sortBy: keyof Feedback, sortOrder: 'asc' | 'desc'): Feedback[] => {
  return [...feedback].sort((a, b) => {
    let valueA = a[sortBy];
    let valueB = b[sortBy];
    
    // Handle dates
    if (valueA instanceof Date && valueB instanceof Date) {
      valueA = valueA.getTime();
      valueB = valueB.getTime();
    }
    
    if (valueA === valueB) return 0;
    
    if (sortOrder === 'asc') {
      return valueA < valueB ? -1 : 1;
    } else {
      return valueA > valueB ? -1 : 1;
    }
  });
};

export const getTruncatedText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return `${text.substring(0, maxLength)}...`;
};