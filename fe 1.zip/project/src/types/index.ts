export interface Feedback {
  id: string;
  name: string;
  email: string;
  type: FeedbackType;
  category: FeedbackCategory;
  subject: string;
  message: string;
  rating: number;
  status: FeedbackStatus;
  createdAt: Date;
  updatedAt: Date | null;
  tags: string[];
  isResolved: boolean;
  assignedTo: string | null;
  response: string | null;
}

export enum FeedbackType {
  SUGGESTION = 'suggestion',
  BUG = 'bug',
  QUESTION = 'question',
  PRAISE = 'praise',
  OTHER = 'other'
}

export enum FeedbackCategory {
  PRODUCT = 'product',
  SERVICE = 'service',
  WEBSITE = 'website',
  PRICING = 'pricing',
  SUPPORT = 'support',
  OTHER = 'other'
}

export enum FeedbackStatus {
  NEW = 'new',
  IN_PROGRESS = 'in_progress',
  RESOLVED = 'resolved',
  CLOSED = 'closed'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
}

export enum UserRole {
  ADMIN = 'admin',
  MANAGER = 'manager',
  VIEWER = 'viewer'
}

export interface FeedbackStats {
  total: number;
  new: number;
  inProgress: number;
  resolved: number;
  closed: number;
  avgRating: number;
  categoryDistribution: Record<FeedbackCategory, number>;
  typeDistribution: Record<FeedbackType, number>;
}

export interface FeedbackFilter {
  search: string;
  type: FeedbackType | '';
  category: FeedbackCategory | '';
  status: FeedbackStatus | '';
  dateRange: {
    from: Date | null;
    to: Date | null;
  };
  minRating: number | null;
  maxRating: number | null;
  tags: string[];
  assignedTo: string | null;
}