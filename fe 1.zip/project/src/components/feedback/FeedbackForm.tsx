import React, { useState } from 'react';
import { FeedbackCategory, FeedbackType } from '../../types';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Textarea from '../ui/Textarea';
import Button from '../ui/Button';
import Card, { CardHeader, CardBody, CardFooter } from '../ui/Card';
import StarRating from '../ui/StarRating';
import { useFeedback } from '../../context/FeedbackContext';
import { getCategoryLabel, getTypeLabel } from '../../utils/helpers';

const FeedbackForm: React.FC = () => {
  const { addFeedback } = useFeedback();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    type: FeedbackType.SUGGESTION,
    category: FeedbackCategory.PRODUCT,
    subject: '',
    message: '',
    rating: 5,
    tags: [] as string[],
  });
  
  const [formErrors, setFormErrors] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  
  const [tag, setTag] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (formErrors[name as keyof typeof formErrors]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };
  
  const handleRatingChange = (rating: number) => {
    setFormData(prev => ({ ...prev, rating }));
  };
  
  const addTag = () => {
    if (tag.trim() && !formData.tags.includes(tag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, tag.trim()]
      }));
      setTag('');
    }
  };
  
  const removeTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(t => t !== tagToRemove)
    }));
  };
  
  const validateForm = () => {
    const errors = {
      name: '',
      email: '',
      subject: '',
      message: '',
    };
    let isValid = true;
    
    if (!formData.name.trim()) {
      errors.name = 'Name is required';
      isValid = false;
    }
    
    if (!formData.email.trim()) {
      errors.email = 'Email is required';
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Email is invalid';
      isValid = false;
    }
    
    if (!formData.subject.trim()) {
      errors.subject = 'Subject is required';
      isValid = false;
    }
    
    if (!formData.message.trim()) {
      errors.message = 'Feedback message is required';
      isValid = false;
    }
    
    setFormErrors(errors);
    return isValid;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      addFeedback(formData);
      setSubmitting(false);
      setSubmitted(true);
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        type: FeedbackType.SUGGESTION,
        category: FeedbackCategory.PRODUCT,
        subject: '',
        message: '',
        rating: 5,
        tags: [],
      });
      
      // Reset submitted status after 3 seconds
      setTimeout(() => {
        setSubmitted(false);
      }, 3000);
    }, 500);
  };
  
  const typeOptions = Object.values(FeedbackType).map(type => ({
    value: type,
    label: getTypeLabel(type)
  }));
  
  const categoryOptions = Object.values(FeedbackCategory).map(category => ({
    value: category,
    label: getCategoryLabel(category)
  }));
  
  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <h2 className="text-2xl font-bold text-gray-800">Submit Your Feedback</h2>
        <p className="text-gray-600 mt-1">
          We value your input and strive to improve based on your feedback.
        </p>
      </CardHeader>
      
      <CardBody>
        {submitted ? (
          <div className="text-center py-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
              <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Thank You for Your Feedback!</h3>
            <p className="text-gray-600">
              Your input has been submitted successfully and will be reviewed by our team.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                id="name"
                name="name"
                label="Your Name"
                value={formData.name}
                onChange={handleChange}
                required
                error={formErrors.name}
              />
              
              <Input
                id="email"
                name="email"
                type="email"
                label="Email Address"
                value={formData.email}
                onChange={handleChange}
                required
                error={formErrors.email}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Select
                id="type"
                name="type"
                label="Feedback Type"
                options={typeOptions}
                value={formData.type}
                onChange={handleChange}
              />
              
              <Select
                id="category"
                name="category"
                label="Category"
                options={categoryOptions}
                value={formData.category}
                onChange={handleChange}
              />
            </div>
            
            <Input
              id="subject"
              name="subject"
              label="Subject"
              value={formData.subject}
              onChange={handleChange}
              required
              error={formErrors.subject}
            />
            
            <Textarea
              id="message"
              name="message"
              label="Your Feedback"
              value={formData.message}
              onChange={handleChange}
              rows={5}
              required
              error={formErrors.message}
            />
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Rating
              </label>
              <StarRating
                rating={formData.rating}
                editable
                onChange={handleRatingChange}
                size="lg"
              />
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Tags (optional)
              </label>
              <div className="flex">
                <Input
                  id="tag"
                  value={tag}
                  onChange={e => setTag(e.target.value)}
                  placeholder="Add a tag"
                  className="mb-0 mr-2 flex-1"
                />
                <Button
                  type="button"
                  variant="secondary"
                  onClick={addTag}
                >
                  Add
                </Button>
              </div>
              
              {formData.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {formData.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center rounded-full bg-blue-100 px-3 py-0.5 text-sm font-medium text-blue-800"
                    >
                      {tag}
                      <button
                        type="button"
                        className="ml-1.5 inline-flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full text-blue-400 hover:bg-blue-200 hover:text-blue-500 focus:bg-blue-500 focus:text-white focus:outline-none"
                        onClick={() => removeTag(tag)}
                      >
                        <span className="sr-only">Remove tag</span>
                        <svg className="h-2 w-2" stroke="currentColor" fill="none" viewBox="0 0 8 8">
                          <path strokeLinecap="round" strokeWidth="1.5" d="M1 1l6 6m0-6L1 7" />
                        </svg>
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>
            
            <div className="mt-6">
              <Button
                type="submit"
                variant="primary"
                fullWidth
                disabled={submitting}
              >
                {submitting ? 'Submitting...' : 'Submit Feedback'}
              </Button>
            </div>
          </form>
        )}
      </CardBody>
    </Card>
  );
};

export default FeedbackForm;