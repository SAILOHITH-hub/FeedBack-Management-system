import React, { useState } from 'react';
import { Feedback, FeedbackStatus, User } from '../../types';
import Card, { CardBody, CardFooter } from '../ui/Card';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import StarRating from '../ui/StarRating';
import { 
  formatDate, 
  getCategoryLabel, 
  getStatusColor, 
  getStatusLabel, 
  getTypeIcon, 
  getTypeLabel 
} from '../../utils/helpers';
import { MessageSquare, Flag, User as UserIcon } from 'lucide-react';
import { useFeedback } from '../../context/FeedbackContext';

interface FeedbackItemProps {
  feedback: Feedback;
  detailed?: boolean;
  onStatusChange?: (id: string, status: FeedbackStatus) => void;
}

const FeedbackItem: React.FC<FeedbackItemProps> = ({ 
  feedback, 
  detailed = false,
  onStatusChange 
}) => {
  const { users, updateFeedback } = useFeedback();
  const [isResponding, setIsResponding] = useState(false);
  const [response, setResponse] = useState(feedback.response || '');
  
  const handleStatusChange = (status: FeedbackStatus) => {
    if (onStatusChange) {
      onStatusChange(feedback.id, status);
    }
  };
  
  const handleAssignToUser = (userId: string) => {
    updateFeedback(feedback.id, { assignedTo: userId });
  };
  
  const handleSubmitResponse = () => {
    if (response.trim()) {
      updateFeedback(feedback.id, { 
        response,
        status: FeedbackStatus.RESOLVED,
        isResolved: true 
      });
      setIsResponding(false);
    }
  };
  
  const renderTags = () => {
    if (feedback.tags.length === 0) return null;
    
    return (
      <div className="flex flex-wrap gap-1 mt-2">
        {feedback.tags.map((tag, index) => (
          <Badge 
            key={index} 
            text={tag} 
            color="gray" 
            size="sm" 
          />
        ))}
      </div>
    );
  };
  
  const renderAssignedUser = () => {
    if (!feedback.assignedTo) return null;
    
    const assignedUser = users.find(user => user.id === feedback.assignedTo);
    if (!assignedUser) return null;
    
    return (
      <div className="flex items-center mt-4 text-sm text-gray-500">
        <UserIcon className="h-4 w-4 mr-1" />
        <span>Assigned to: </span>
        <span className="ml-1 font-medium text-gray-700 flex items-center">
          <img 
            src={assignedUser.avatar} 
            alt={assignedUser.name} 
            className="h-5 w-5 rounded-full mr-1"
          />
          {assignedUser.name}
        </span>
      </div>
    );
  };
  
  const getStatusBadgeColor = (status: FeedbackStatus): 'blue' | 'green' | 'yellow' | 'gray' => {
    switch (status) {
      case FeedbackStatus.NEW:
        return 'blue';
      case FeedbackStatus.IN_PROGRESS:
        return 'yellow';
      case FeedbackStatus.RESOLVED:
        return 'green';
      case FeedbackStatus.CLOSED:
        return 'gray';
      default:
        return 'gray';
    }
  };
  
  return (
    <Card hover className={detailed ? '' : 'h-full'}>
      <CardBody className="pb-3">
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-medium text-gray-900 flex items-center">
            <span className="mr-2 text-xl">{getTypeIcon(feedback.type)}</span>
            {feedback.subject}
          </h3>
          <div className="flex items-center">
            <Badge 
              text={getStatusLabel(feedback.status)} 
              color={getStatusBadgeColor(feedback.status)}
            />
          </div>
        </div>
        
        <div className="flex justify-between items-center mt-2 text-sm text-gray-500">
          <div className="flex items-center">
            <span className="mr-2">{feedback.name}</span>
            <span>•</span>
            <span className="ml-2">{formatDate(feedback.createdAt)}</span>
          </div>
          <StarRating rating={feedback.rating} size="sm" />
        </div>
        
        <div className="mt-3">
          <p className="text-gray-600">
            {detailed ? feedback.message : `${feedback.message.substring(0, 150)}${feedback.message.length > 150 ? '...' : ''}`}
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2 mt-3">
          <Badge 
            text={getCategoryLabel(feedback.category)} 
            color="purple" 
          />
          <Badge 
            text={getTypeLabel(feedback.type)} 
            color="blue" 
          />
          {renderTags()}
        </div>
        
        {renderAssignedUser()}
        
        {feedback.response && (
          <div className="mt-4 bg-gray-50 p-3 rounded-md border border-gray-200">
            <h4 className="font-medium text-gray-900 mb-1">Response:</h4>
            <p className="text-gray-600 text-sm">{feedback.response}</p>
          </div>
        )}
      </CardBody>
      
      {detailed && (
        <CardFooter className="bg-gray-50 border-t border-gray-200">
          {isResponding ? (
            <div className="w-full">
              <textarea
                className="w-full p-2 border border-gray-300 rounded-md text-sm"
                rows={3}
                placeholder="Type your response here..."
                value={response}
                onChange={(e) => setResponse(e.target.value)}
              ></textarea>
              <div className="flex justify-end space-x-2 mt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsResponding(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={handleSubmitResponse}
                >
                  Submit Response
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex flex-wrap justify-between w-full">
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsResponding(true)}
                  icon={<MessageSquare className="h-4 w-4" />}
                >
                  Respond
                </Button>
                
                <div className="relative group">
                  <Button
                    variant="outline"
                    size="sm"
                    icon={<Flag className="h-4 w-4" />}
                  >
                    Status
                  </Button>
                  <div className="absolute z-10 hidden group-hover:block bg-white border border-gray-200 rounded-md shadow-lg p-2 w-36 top-full left-0 mt-1">
                    {Object.values(FeedbackStatus).map((status) => (
                      <button
                        key={status}
                        className="block w-full text-left px-3 py-1 text-sm hover:bg-gray-100 rounded"
                        onClick={() => handleStatusChange(status)}
                      >
                        <span className={`inline-block w-2 h-2 rounded-full ${getStatusColor(status)} mr-2`}></span>
                        {getStatusLabel(status)}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="relative group">
                  <Button
                    variant="outline"
                    size="sm"
                    icon={<UserIcon className="h-4 w-4" />}
                  >
                    Assign
                  </Button>
                  <div className="absolute z-10 hidden group-hover:block bg-white border border-gray-200 rounded-md shadow-lg p-2 w-48 top-full left-0 mt-1">
                    {users.map((user) => (
                      <button
                        key={user.id}
                        className="block w-full text-left px-3 py-1 text-sm hover:bg-gray-100 rounded flex items-center"
                        onClick={() => handleAssignToUser(user.id)}
                      >
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-5 h-5 rounded-full mr-2"
                        />
                        {user.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardFooter>
      )}
    </Card>
  );
};

export default FeedbackItem;