import React from 'react';
import Card, { CardHeader, CardBody } from '../ui/Card';
import { useFeedback } from '../../context/FeedbackContext';
import StarRating from '../ui/StarRating';

const RatingDistribution: React.FC = () => {
  const { feedbacks } = useFeedback();
  
  // Count feedbacks by rating
  const ratingCounts = [0, 0, 0, 0, 0]; // For ratings 1-5
  feedbacks.forEach(feedback => {
    if (feedback.rating >= 1 && feedback.rating <= 5) {
      ratingCounts[feedback.rating - 1]++;
    }
  });
  
  // Calculate total for percentage
  const total = ratingCounts.reduce((sum, count) => sum + count, 0);
  
  // Calculate average rating
  const sum = feedbacks.reduce((acc, feedback) => acc + feedback.rating, 0);
  const averageRating = total > 0 ? (sum / total).toFixed(1) : '0.0';
  
  // Render the rating bars
  const ratingBars = [5, 4, 3, 2, 1].map(rating => {
    const count = ratingCounts[rating - 1];
    const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
    
    return (
      <div key={rating} className="flex items-center mt-2">
        <div className="w-12 flex items-center">
          <span className="text-sm font-medium text-gray-700">{rating}</span>
          <svg className="w-4 h-4 text-amber-400 ml-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
          </svg>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5 ml-2">
          <div
            className="h-2.5 rounded-full bg-amber-400"
            style={{ width: `${percentage}%` }}
          ></div>
        </div>
        <span className="text-sm font-medium text-gray-700 ml-2 w-12 text-right">
          {percentage}%
        </span>
      </div>
    );
  });
  
  return (
    <Card>
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-900">Rating Distribution</h2>
      </CardHeader>
      <CardBody>
        <div className="flex items-center justify-between mb-6">
          <div className="text-center">
            <p className="text-3xl font-bold text-gray-900">{averageRating}</p>
            <div className="flex justify-center mt-1">
              <StarRating rating={parseFloat(averageRating)} />
            </div>
            <p className="text-sm text-gray-500 mt-1">{total} ratings</p>
          </div>
          <div className="w-3/4">
            {ratingBars}
          </div>
        </div>
      </CardBody>
    </Card>
  );
};

export default RatingDistribution;