import React from 'react';
import Card, { CardBody } from '../ui/Card';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  change?: {
    value: number;
    type: 'increase' | 'decrease';
  };
  color?: 'blue' | 'green' | 'amber' | 'red' | 'purple' | 'gray';
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon,
  change,
  color = 'blue'
}) => {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-green-50 text-green-600',
    amber: 'bg-amber-50 text-amber-600',
    red: 'bg-red-50 text-red-600',
    purple: 'bg-purple-50 text-purple-600',
    gray: 'bg-gray-50 text-gray-600'
  };
  
  const changeColorClasses = {
    increase: 'text-green-600',
    decrease: 'text-red-600'
  };
  
  const changeIconClasses = {
    increase: '↑',
    decrease: '↓'
  };
  
  return (
    <Card className="h-full transition-all duration-300 hover:shadow-md">
      <CardBody>
        <div className="flex items-center mb-3">
          <div className={`p-2 rounded-lg ${colorClasses[color]}`}>
            {icon}
          </div>
        </div>
        <h3 className="text-sm font-medium text-gray-500 mb-1">{title}</h3>
        <div className="flex items-end justify-between">
          <p className="text-2xl font-bold text-gray-900">{value}</p>
          {change && (
            <div className={`flex items-center text-sm font-medium ${changeColorClasses[change.type]}`}>
              <span className="mr-1">{changeIconClasses[change.type]}</span>
              {change.value}%
            </div>
          )}
        </div>
      </CardBody>
    </Card>
  );
};

export default StatCard;